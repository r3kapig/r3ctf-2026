```sh
sudo docker build . -t r3ctf-definitely-not-a-web-chal .
sudo docker run --rm -p 8082:80 r3ctf-definitely-not-a-web-chal

URL=http://127.0.0.1:8082/ python3 ../work/solve.py
```
